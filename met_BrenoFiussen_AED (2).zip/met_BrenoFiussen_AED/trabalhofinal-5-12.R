library(dplyr)
install.packages("lubridate")
library(lubridate)
library(datasets)
library(ggplot2)
dadosmet<-read.csv("dados.csv", sep = ";", header = TRUE)
View(dadosmet)

names<-c("Data", "Chuva_mm", "TempMax", "TempMed", "TempMin", "UmidadeR", "VentoRj_ms", "VentoVelMed_ms","X")

colnames(dadosmet, do.NULL = TRUE, prefix = "col")

colnames(dadosmet) <- names

summary(dadosmet)#resume os dados
str(dadosmet)#verifica o tipo
#transforma os dados$precip... para numerico no objeto precipitação
dadosmet$Chuva_mm<-as.numeric(dadosmet$Chuva_mm)
dadosmet$TempMax<-as.numeric(dadosmet$TempMax)
dadosmet$TempMed<-as.numeric(dadosmet$TempMed)
dadosmet$TempMin<-as.numeric(dadosmet$TempMin)
dadosmet$UmidadeR<-as.numeric(dadosmet$UmidadeR)
dadosmet$VentoRj_ms<-as.numeric(dadosmet$VentoRj_ms)
dadosmet$VentoVelMed_ms<-as.numeric(dadosmet$VentoVelMed_ms)
summary(dadosmet)

# criando tres vetores (dia, mes e ano)

temp<-as.Date(dadosmet$Data)
class(temp)

dia<-as.numeric(format(temp, format = "%d"))
mes<-as.factor(format(temp, format = "%m"))
ano<-as.numeric(format(temp, format = "%Y"))

dadosmet<-cbind(dia,mes,ano,dadosmet)


#coletando dados

summary(dadosmet$Chuva_mm)
sd(dadosmet$Chuva_mm,na.rm = TRUE)

boxplot(dadosmet$Chuva_mm)
title(main = "Chuva (mm)")
###########################

summary(dadosmet$TempMax)
sd(dadosmet$TempMax,na.rm = TRUE)

summary(dadosmet$TempMed)
sd(dadosmet$TempMed,na.rm = TRUE)

summary(dadosmet$TempMin)
sd(dadosmet$TempMin,na.rm = TRUE)

boxplot(dadosmet$TempMax,dadosmet$TempMed,dadosmet$TempMin, 
        main = "Temperatura °C") 
names <- c("TempMax", "TempMed", "TempMin")
        axis(1, at=1:3, labels=names)


###########################

summary(dadosmet$UmidadeR)
sd(dadosmet$UmidadeR,na.rm = TRUE)

boxplot(dadosmet$UmidadeR)

###########################

summary(dadosmet$VentoRj_ms)
sd(dadosmet$VentoRj_ms,na.rm = TRUE)

summary(dadosmet$VentoVelMed_ms)
sd(dadosmet$VentoVelMed_ms,na.rm = TRUE)

boxplot(dadosmet$VentoRj_ms,dadosmet$VentoVelMed_ms)

hist(dadosmet$VentoVelMed_ms)

###########################

#salvando imagem
save.image("trabalhofinal.RData")  

