install.packages("tidyr")
library("tidyr")
install.packages("fdth")
library("fdth")
install.packages("dplyr")
library("dplyr")
install.packages("xtable")
library("xtable")
dadosmet<-read.csv("dados.csv", sep = ";", header = TRUE)
View(dadosmet)

names<-c("Data", 
         "Chuva_mm", 
         "TempMax", 
         "TempMed", 
         "TempMin", 
         "UmidadeR", 
         "VentoRj_ms", 
         "VentoVelMed_ms","X")

colnames(dadosmet, do.NULL = TRUE, prefix = "col")

colnames(dadosmet) <- names

summary(dadosmet)#resume os dados
str(dadosmet)#verifica o tipo
#transforma os dados$precip... para numerico no objeto precipitação
dadosmet$Chuva_mm<-as.numeric(dadosmet$Chuva_mm)
dadosmet$TempMax<-as.numeric(dadosmet$TempMax)
dadosmet$TempMed<-as.numeric(dadosmet$TempMed)
dadosmet$TempMin<-as.numeric(dadosmet$TempMin)
dadosmet$UmidadeR<-as.numeric(dadosmet$UmidadeR)
dadosmet$VentoRj_ms<-as.numeric(dadosmet$VentoRj_ms)
dadosmet$VentoVelMed_ms<-as.numeric(dadosmet$VentoVelMed_ms)
summary(dadosmet)

# criando tres vetores (dia, mes e ano)

temp<-as.Date(dadosmet$Data)
class(temp)

dia<-as.numeric(format(temp, format = "%d"))
mes<-as.factor(format(temp, format = "%m"))
ano<-as.numeric(format(temp, format = "%Y"))

dadosmet<-cbind(dia,mes,ano,dadosmet)


#coletando dados

summary(dadosmet$Chuva_mm)
sd(dadosmet$Chuva_mm,na.rm = TRUE)

boxplot(dadosmet$Chuva_mm)
title(main = "Chuva (mm)")
###########################

summary(dadosmet$TempMax)
sd(dadosmet$TempMax,na.rm = TRUE)

summary(dadosmet$TempMed)
sd(dadosmet$TempMed,na.rm = TRUE)

summary(dadosmet$TempMin)
sd(dadosmet$TempMin,na.rm = TRUE)

boxplot(dadosmet$TempMax,dadosmet$TempMed,dadosmet$TempMin, 
        main = "Temperatura °C") 
names <- c("TempMax", "TempMed", "TempMin")
axis(1, at=1:3, labels=names)


###########################

summary(dadosmet$UmidadeR)
sd(dadosmet$UmidadeR,na.rm = TRUE)

boxplot(dadosmet$UmidadeR)

###########################

summary(dadosmet$VentoRj_ms)
sd(dadosmet$VentoRj_ms,na.rm = TRUE)

summary(dadosmet$VentoVelMed_ms)
sd(dadosmet$VentoVelMed_ms,na.rm = TRUE)

boxplot(dadosmet$VentoRj_ms,dadosmet$VentoVelMed_ms)

hist(dadosmet$VentoVelMed_ms)

###########################
summary(dadosmet)
summary(dadosmet$Chuva_mm)
sd(dadosmet$Chuva_mm,na.rm = TRUE)
boxplot(dadosmet$Chuva_mm)
title(main = "Chuva (mm)")
summary(dadosmet$TempMax)
sd(dadosmet$TempMax,na.rm = TRUE)
summary(dadosmet$TempMed)
sd(dadosmet$TempMed,na.rm = TRUE)
summary(dadosmet$TempMin)
sd(dadosmet$TempMin,na.rm = TRUE)
boxplot(dadosmet$TempMax,dadosmet$TempMed,dadosmet$TempMin,
        main = "Temperatura °C")
names <- c("TempMax", "TempMed", "TempMin")
axis(1, at=1:3, labels=names)
summary(dadosmet$UmidadeR)
sd(dadosmet$UmidadeR,na.rm = TRUE)
boxplot(dadosmet$UmidadeR)
summary(dadosmet$VentoRj_ms)
sd(dadosmet$VentoRj_ms,na.rm = TRUE)
summary(dadosmet$VentoVelMed_ms)
sd(dadosmet$VentoVelMed_ms,na.rm = TRUE)
boxplot(dadosmet$VentoRj_ms,dadosmet$VentoVelMed_ms)
hist(dadosmet$VentoRj_ms)

## Histograma de temperaturas combinado
h1<-hist(dadosmet$TempMin)
h2<-hist(dadosmet$TempMed)
h3<-hist(dadosmet$TempMax)
plot(h3, col = rgb(0,0,1,1/4),
     main = "Histogramas Temperaturas",
     xlab = "Temperatura (°C)",
     ylab = "Frequencia", 
     ylim = c(min(min(h1$counts), min(h2$counts), min(h3$counts)), 
                  max(max(h1$counts), max(h2$counts), max(h3$counts))),
     xlim = c(0,40))
plot(h2, col=rgb(1,0,0,1/4), add=T)
plot(h1, col=rgb(1,0,0,1/2), add=T)

## criando novos objetos para separar os anos e meses

a22<-dadosmet%>%filter(ano==2022)
a23<-dadosmet%>%filter(ano==2023)

dadosmet %>%
  group_by(ano) %>%
  summarise(med_temp=mean(TempMed, na.rm = TRUE), 
            med_prec=mean(Chuva_mm, na.rm=TRUE),
            med_umid=mean(UmidadeR, na.rm=TRUE),
            med_vent=mean(VentoVelMed_ms, na.rm=TRUE))

summary(dadosmet$TempMed)
summary(dadosmet$Chuva_mm)
dadosmet %>% 
  group_by(ano,mes) %>%
  summarise(med_prec=mean(Chuva_mm, na.rm=TRUE),
            med_tempMax=mean(TempMax, na.rm = TRUE),
            med_tempMed=mean(TempMed, na.rm = TRUE),
            med_tempMin=mean(TempMin, na.rm = TRUE),
            med_umid=mean(UmidadeR, na.rm=TRUE),
            med_ventRaj=mean(VentoVelMed_ms, na.rm=TRUE),
            med_vent=mean(VentoVelMed_ms, na.rm=TRUE))

save.image("met-ead-7-12.RData")

#Chuva por mes e ano
summary(dadosmet$Chuva_mm)
dadosmet %>% 
  group_by(ano,mes) %>%
  summarise(med_prec=mean(Chuva_mm, na.rm=TRUE))

# Resumo dos dados
resumo_dados <- dadosmet %>%
  group_by(ano, mes) %>%
  summarise(med_prec = mean(Chuva_mm, na.rm = TRUE), .groups = 'drop')

# Converter para uma tabela LaTeX
tabela_latex <- xtable(resumo_dados)

# Imprimir a tabela
print(tabela_latex)

# Resumo dos dados
resumo_dados <- dadosmet %>%
  group_by(ano, mes) %>%
  summarise(med_prec = mean(Chuva_mm, na.rm = TRUE), .groups = 'drop')

# Converter para uma tabela LaTeX
tabela_latex <- xtable(resumo_dados)

# Imprimir a tabela
print(tabela_latex)

save.image("met-ead-12-12.RData")

